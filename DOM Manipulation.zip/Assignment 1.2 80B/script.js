let randomNumber = Math.floor(Math.random() * 100) + 1;
let score = 10;

function checkGuess() {
    let userGuess = Number(document.getElementById("guessInput").value);
    let message = document.getElementById("message");

    if (score <= 0) {
        message.innerText = "Game Over! The number was " + randomNumber;
        return;
    }

    if (userGuess === randomNumber) {
        message.innerText = "Correct! You won!";
    } 
    else if (userGuess > randomNumber) {
        message.innerText = "Too High!";
        score--;
    } 
    else {
        message.innerText = "Too Low!";
        score--;
    }

    document.getElementById("score").innerText = score;
    }

function resetGame() {
    randomNumber = Math.floor(Math.random() * 100) + 1;
    score = 10;
    document.getElementById("score").innerText = score;
    document.getElementById("message").innerText = "";
    document.getElementById("guessInput").value = "";
}