function validateForm() {

    let name = document.getElementById("name").value.trim();
    let branchs = document.getElementById("branchs").value.trim();
    let email = document.getElementById("email").value.trim();
    let mobile = document.getElementById("mobile").value.trim();
    let password = document.getElementById("password").value;
    let confirmPassword = document.getElementById("confirmPassword").value;
    let errorMsg = document.getElementById("errorMsg");

    errorMsg.innerHTML = "";

    if (name === "") {
        errorMsg.innerHTML = "Name is required";
        return false;
    }

    if(branchs === "") {
        errorMsg.innerHTML = "Branch is required";
        return false;
    }
    let emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
        errorMsg.innerHTML = "Enter a valid email address";
        return false;
    }

    let mobilePattern = /^[0-9]{10}$/;
    if (!mobilePattern.test(mobile)) {
        errorMsg.innerHTML = "Enter a valid 10-digit mobile number";
        return false;
    }

    let passwordPattern = /^[A-Za-z0-9][A-Za-z0-9@#$%^&*!]{5,}$/;

    if (!passwordPattern.test(password)) {
        errorMsg.innerHTML = "Password must not start with special character and be at least 6 characters";
        return false;
    }

    if (password !== confirmPassword) {
        errorMsg.innerHTML = "Passwords do not match";
        return false;
    }

    alert("Registration Successful!");
    return true;
}
